﻿//Grade ID: N8838
//Program 4
//Due: April 23, 2019
//CIS 199-75
// This program explores the creation of a reusable class and separate console application that creates an array of objects. displaying packages in methods.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
    class GroundPackage
    {
        private const int low_zip = 00000, //ths is the lowest zip we can delivery to
                          max_zip = 99999, // highest zip we deliver to
                          default_origin = 40202, // default orgin zip
                          default_destination = 90210; // default destination zip

        private const double min_value = 0, //minimum value for length, width, height, and weight
                            default_value = 1;  // Defaults values for length, width, height, and weight

        private int _originZip, // orgin zip
                    _destinationzip; // destination zip

        private double _length, // length of package
                       _width,  // width or package
                        _height,  // height of package
                        _weight;  // weight of package

        //Precondition: sets paramaters for groundpackages 
        //Postcondition: sets prarmeters in list 
        public GroundPackage(int Origin, int Destination, double length, double width, double height, double weight)
        {
            OriginZip = Origin;
            DestinationZip = Destination;
            Lengths = length;
            Widths = width;
            Heights = height;
            Weights = weight;
        }

        //PreCondition: if value for orgin zip is not valid, it will be set to default 
        //PostCondition: returns the valid value or default to orgin zip method 
        public int OriginZip
        {
            get
            {
                return _originZip;
            }

            set
            {
                if (value >= low_zip && value <= max_zip)
                    _originZip = value;
                else
                    _originZip = default_origin;
            }
        }

        //PreCondition: if value is not valid for dest. zip>=00000 <=99999 sets to default 
        //PostCondtition: returns valid destination zip
        public int DestinationZip
        {
            get
            {
                return _destinationzip;
            }

            set
            {
                if (value >= low_zip && value <= max_zip)
                    _destinationzip = value;
                else
                    _destinationzip = default_destination;

            }
        }
        //Precodition : if value is less then 0 it sets it to default
        //postcondition: returns valid length >=1
        public double Lengths
        {
            get
            {
                return _length;
            }

            set
            {
                if (value >= min_value)
                    _length = value;
                else
                    _length = default_value;
            }
        }
        //Precodition : if value is less then 0 it sets it to default
        //postcondition: returns valid width >=1
        public double Widths
        {
            get
            {
                return _width;
            }
            set
            {
                if (value >= min_value)
                    _width = value;
                else
                    _width = default_value;
            }
        }
        //Precondition : Hight >= value
        //postcondition height is set and returned with valid value
        public double Heights
        {
            get
            {
                return _height;
            }
            set
            {
                if (value >= min_value)
                    _height = value;
                else
                    _height = default_value;
            }
        }
        //precondition: if value for weight is valid, if not sets to 1.0
        //postcondition: returns weight using valid value
        public double Weights
        {
            get
            {
                return _weight;
            }

            set
            {
                if (value >= min_value)
                    _weight = value;
                else
                    _weight = default_value;
            }
        }
        //precondition: destination and origin zip codes
        //Postcondition: returns distance between the origin and destiantion zip codes
        public int ZoneDistance
        {
            get
            {
                int firstOrgin = OriginZip / 10000;
                int firstDest = DestinationZip / 10000;
                return (firstDest - firstOrgin);
            }
        }

        //Precondition:Calculates costs using given formula in BB
        //Postcondition: returns cost to CalcCost method

        public double CalcCost()
        {
            const double SIZE_COST_FACTOR = 0.25;
            const double WEIGHT_COST_FACTOR = 0.45;

            return SIZE_COST_FACTOR * (Lengths + Widths + Heights) + WEIGHT_COST_FACTOR * (ZoneDistance + 1) * (Weights);
        }
        // precondition:
        //postcondition: string inerpolation carrying packages information is created and returned.
        public override string ToString()
        {
            return $"Origin Zip: {OriginZip:D5}{Environment.NewLine}" +
                   $"Destination Zip: {DestinationZip:D5}{Environment.NewLine}" +
                   $"Length: {Lengths}{Environment.NewLine}" +
                   $"Width: {Widths}{Environment.NewLine}" +
                   $"Height: {Heights}{Environment.NewLine}" +
                   $"Weight: {Weights}";
        }
    }
}
