﻿//Grade ID: N8838
//Program 4
//Due: April 23, 2019
//CIS 199-75
// This program explores the creation of a reusable class and separate console application that creates an array of objects. displaying packages in methods.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
    class Program
    {
        static void Main(string[] args)
        {
            GroundPackage[] packages = new GroundPackage[5];
                
            // below is 5 objects of ground packages class
            packages[0] = new GroundPackage(40219, 41020, 8.5, 6.6, 3.4, 2.5);
            packages[1] = new GroundPackage(40290, 54343, 11.5, 7.0, 4.6, 3.7);
            packages[2] = new GroundPackage(50000, 38293, 13.5, 8.3, 5.8, 1.5);
            packages[3] = new GroundPackage(14232, 30224, 15.6, 8.5, 9.1, 6.5);
            packages[4] = new GroundPackage(40216, 40202, 9.9, 6.1, 5.9, 9.9);
        
            //a call to display packages
            DisplayPackages(packages);
            // Changes to some packages then displays it
            packages[0].Widths = 4.5;
            packages[1].OriginZip = 40299;
            packages[2].Heights = 3;
            packages[2].Lengths = 6.3;
            packages[3].Heights = 9;
            packages[4].OriginZip = 40210;

            DisplayPackages(packages);
        }
        //Precondiition : using for loop over the packages until loop ends.
        //Postcondition: Displays packages to console
        public static void DisplayPackages(GroundPackage[] packages)
        {
            for (int i = 0; i < packages.Length; i++)
            {
                Console.WriteLine($"{packages[i].ToString()}");
                Console.WriteLine($"{packages[i].CalcCost():C}");
                Console.WriteLine();
            }
        }

        }
    }

