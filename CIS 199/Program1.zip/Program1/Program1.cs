﻿//Grade ID: N8838
//CIS 199-75
//Program1
//Due Date: February 12th 2019
//This program is called the Handy-Dandy Carpet Estimator, its a windows form program that will be used to
//calculate estimating the materials and labor costs for our carpet sales and installation company
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program1
{
    public partial class Program1 : Form
    {
        public Program1()
        {
            InitializeComponent();
        }
        //this is my button name
        private void CalculateBtn_Click(object sender, EventArgs e)
        {
            //these are my input variables
            double maxwidthRm;
            double maxlengthRm;
            double carpetPr;
            int paddingNum;
            int firstRm;

            //these are my out-put variables
            double SqrYrdNeed;
            double carptCost;
            double paddingCost;
            double LbrCost = 0;
            double TotalCost;

            //this enters max wdith of room
            maxwidthRm = double.Parse(RmWidthInput.Text);
            //Enters Room Length
            maxlengthRm = double.Parse(RmLengthInput.Text);
            //Inputs Carpet Price
            carpetPr = double.Parse(crptPriceInput.Text);
            //Inputs Layers of padding
            paddingNum = int.Parse(PadInput.Text);
            //Inputs Asks if this is first room
            firstRm = int.Parse(isRoomInput.Text);

            //Calculation step

            //Converts feet to Yards

            SqrYrdNeed = maxlengthRm * maxwidthRm / 9;

            //this calculates padding cost

            paddingCost = SqrYrdNeed * 2.75 * paddingNum * 1.1;

            //calculate carpet cost

            carptCost = SqrYrdNeed * carpetPr * 1.1;

            //using ifs function to decide if we want to charge extra $100 
            //for first time users or no service charge for loyal customers 
            //if first room we charge $100 if not, then we won't charge $100

            if (firstRm == 1)
            {
                LbrCost = SqrYrdNeed * 4.5 + 100;
            }
            if (firstRm == 0)
            {
                LbrCost = SqrYrdNeed * 4.5;
            }

            TotalCost = paddingCost + carptCost + LbrCost;

            //Labels to display totals and answers F1 is used for decimals, C stands for currency

            SqYrdOut.Text = $"{SqrYrdNeed:F1}";

            PdingCOut.Text = $"{paddingCost:C}";

            CrptcOut.Text = $"{carptCost:C}";

            LabrCOut.Text = $"{LbrCost:C}";

            totalcOut.Text = $"{TotalCost:C}";


        }
        //this is my clear button if clicked it will reset all inputs
        private void ClearBtn_Click(object sender, EventArgs e)
        {
            RmWidthInput.Clear();
            RmLengthInput.Clear();
            crptPriceInput.Clear();
            PadInput.Clear();
            isRoomInput.Clear();
            

        }
    }
}
