﻿namespace Program1
{
    partial class Program1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.welcomeLBL = new System.Windows.Forms.Label();
            this.rmWidthLbl = new System.Windows.Forms.Label();
            this.RmWidthInput = new System.Windows.Forms.TextBox();
            this.RmLengthLbl = new System.Windows.Forms.Label();
            this.RmLengthInput = new System.Windows.Forms.TextBox();
            this.CrptPrLbl = new System.Windows.Forms.Label();
            this.crptPriceInput = new System.Windows.Forms.TextBox();
            this.paddingInput = new System.Windows.Forms.Label();
            this.isRoomLbl = new System.Windows.Forms.Label();
            this.PadInput = new System.Windows.Forms.TextBox();
            this.isRoomInput = new System.Windows.Forms.TextBox();
            this.SqYrdIn = new System.Windows.Forms.Label();
            this.CrptcIn = new System.Windows.Forms.Label();
            this.PdingCIn = new System.Windows.Forms.Label();
            this.LabrCIn = new System.Windows.Forms.Label();
            this.totalcIn = new System.Windows.Forms.Label();
            this.SqYrdOut = new System.Windows.Forms.Label();
            this.CrptcOut = new System.Windows.Forms.Label();
            this.PdingCOut = new System.Windows.Forms.Label();
            this.LabrCOut = new System.Windows.Forms.Label();
            this.totalcOut = new System.Windows.Forms.Label();
            this.CalculateBtn = new System.Windows.Forms.Button();
            this.ClearBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // welcomeLBL
            // 
            this.welcomeLBL.AutoSize = true;
            this.welcomeLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.welcomeLBL.Location = new System.Drawing.Point(68, 25);
            this.welcomeLBL.Name = "welcomeLBL";
            this.welcomeLBL.Size = new System.Drawing.Size(447, 24);
            this.welcomeLBL.TabIndex = 0;
            this.welcomeLBL.Text = "Welcome to the Handy-Dandy Carpet Estimator";
            // 
            // rmWidthLbl
            // 
            this.rmWidthLbl.AutoSize = true;
            this.rmWidthLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rmWidthLbl.Location = new System.Drawing.Point(22, 80);
            this.rmWidthLbl.Name = "rmWidthLbl";
            this.rmWidthLbl.Size = new System.Drawing.Size(200, 13);
            this.rmWidthLbl.TabIndex = 1;
            this.rmWidthLbl.Text = "Enter the max width of the room in (feet): ";
            // 
            // RmWidthInput
            // 
            this.RmWidthInput.Location = new System.Drawing.Point(228, 77);
            this.RmWidthInput.Name = "RmWidthInput";
            this.RmWidthInput.Size = new System.Drawing.Size(57, 20);
            this.RmWidthInput.TabIndex = 2;
            // 
            // RmLengthLbl
            // 
            this.RmLengthLbl.AutoSize = true;
            this.RmLengthLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RmLengthLbl.Location = new System.Drawing.Point(23, 121);
            this.RmLengthLbl.Name = "RmLengthLbl";
            this.RmLengthLbl.Size = new System.Drawing.Size(204, 13);
            this.RmLengthLbl.TabIndex = 3;
            this.RmLengthLbl.Text = "Enter the max length of the room in (feet): ";
            // 
            // RmLengthInput
            // 
            this.RmLengthInput.Location = new System.Drawing.Point(227, 121);
            this.RmLengthInput.Name = "RmLengthInput";
            this.RmLengthInput.Size = new System.Drawing.Size(58, 20);
            this.RmLengthInput.TabIndex = 4;
            // 
            // CrptPrLbl
            // 
            this.CrptPrLbl.AutoSize = true;
            this.CrptPrLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CrptPrLbl.Location = new System.Drawing.Point(46, 154);
            this.CrptPrLbl.Name = "CrptPrLbl";
            this.CrptPrLbl.Size = new System.Drawing.Size(176, 13);
            this.CrptPrLbl.TabIndex = 5;
            this.CrptPrLbl.Text = "Enter the carpet price (per sqr yard):";
            // 
            // crptPriceInput
            // 
            this.crptPriceInput.Location = new System.Drawing.Point(228, 151);
            this.crptPriceInput.Name = "crptPriceInput";
            this.crptPriceInput.Size = new System.Drawing.Size(57, 20);
            this.crptPriceInput.TabIndex = 6;
            // 
            // paddingInput
            // 
            this.paddingInput.AutoSize = true;
            this.paddingInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paddingInput.Location = new System.Drawing.Point(33, 185);
            this.paddingInput.Name = "paddingInput";
            this.paddingInput.Size = new System.Drawing.Size(189, 13);
            this.paddingInput.TabIndex = 7;
            this.paddingInput.Text = "Enter layers of padding to use (1 or 2): ";
            // 
            // isRoomLbl
            // 
            this.isRoomLbl.AutoSize = true;
            this.isRoomLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.isRoomLbl.Location = new System.Drawing.Point(22, 218);
            this.isRoomLbl.Name = "isRoomLbl";
            this.isRoomLbl.Size = new System.Drawing.Size(197, 13);
            this.isRoomLbl.TabIndex = 8;
            this.isRoomLbl.Text = "Is this the first room? (1 = YES, 0 = NO): ";
            // 
            // PadInput
            // 
            this.PadInput.Location = new System.Drawing.Point(228, 185);
            this.PadInput.Name = "PadInput";
            this.PadInput.Size = new System.Drawing.Size(57, 20);
            this.PadInput.TabIndex = 9;
            // 
            // isRoomInput
            // 
            this.isRoomInput.Location = new System.Drawing.Point(228, 218);
            this.isRoomInput.Name = "isRoomInput";
            this.isRoomInput.Size = new System.Drawing.Size(57, 20);
            this.isRoomInput.TabIndex = 10;
            // 
            // SqYrdIn
            // 
            this.SqYrdIn.AutoSize = true;
            this.SqYrdIn.Location = new System.Drawing.Point(322, 80);
            this.SqYrdIn.Name = "SqYrdIn";
            this.SqYrdIn.Size = new System.Drawing.Size(97, 13);
            this.SqYrdIn.TabIndex = 11;
            this.SqYrdIn.Text = "Sq. Yards Needed:";
            // 
            // CrptcIn
            // 
            this.CrptcIn.AutoSize = true;
            this.CrptcIn.Location = new System.Drawing.Point(354, 121);
            this.CrptcIn.Name = "CrptcIn";
            this.CrptcIn.Size = new System.Drawing.Size(65, 13);
            this.CrptcIn.TabIndex = 12;
            this.CrptcIn.Text = "Carpet Cost:";
            // 
            // PdingCIn
            // 
            this.PdingCIn.AutoSize = true;
            this.PdingCIn.Location = new System.Drawing.Point(346, 154);
            this.PdingCIn.Name = "PdingCIn";
            this.PdingCIn.Size = new System.Drawing.Size(73, 13);
            this.PdingCIn.TabIndex = 13;
            this.PdingCIn.Text = "Padding Cost:";
            // 
            // LabrCIn
            // 
            this.LabrCIn.AutoSize = true;
            this.LabrCIn.Location = new System.Drawing.Point(358, 188);
            this.LabrCIn.Name = "LabrCIn";
            this.LabrCIn.Size = new System.Drawing.Size(61, 13);
            this.LabrCIn.TabIndex = 14;
            this.LabrCIn.Text = "Labor Cost:";
            // 
            // totalcIn
            // 
            this.totalcIn.AutoSize = true;
            this.totalcIn.Location = new System.Drawing.Point(361, 221);
            this.totalcIn.Name = "totalcIn";
            this.totalcIn.Size = new System.Drawing.Size(58, 13);
            this.totalcIn.TabIndex = 15;
            this.totalcIn.Text = "Total Cost:";
            // 
            // SqYrdOut
            // 
            this.SqYrdOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SqYrdOut.Location = new System.Drawing.Point(425, 77);
            this.SqYrdOut.Name = "SqYrdOut";
            this.SqYrdOut.Size = new System.Drawing.Size(79, 20);
            this.SqYrdOut.TabIndex = 16;
            // 
            // CrptcOut
            // 
            this.CrptcOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CrptcOut.Location = new System.Drawing.Point(425, 120);
            this.CrptcOut.Name = "CrptcOut";
            this.CrptcOut.Size = new System.Drawing.Size(79, 21);
            this.CrptcOut.TabIndex = 17;
            // 
            // PdingCOut
            // 
            this.PdingCOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PdingCOut.Location = new System.Drawing.Point(425, 154);
            this.PdingCOut.Name = "PdingCOut";
            this.PdingCOut.Size = new System.Drawing.Size(79, 20);
            this.PdingCOut.TabIndex = 18;
            // 
            // LabrCOut
            // 
            this.LabrCOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LabrCOut.Location = new System.Drawing.Point(425, 188);
            this.LabrCOut.Name = "LabrCOut";
            this.LabrCOut.Size = new System.Drawing.Size(79, 20);
            this.LabrCOut.TabIndex = 19;
            // 
            // totalcOut
            // 
            this.totalcOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalcOut.Location = new System.Drawing.Point(425, 217);
            this.totalcOut.Name = "totalcOut";
            this.totalcOut.Size = new System.Drawing.Size(79, 20);
            this.totalcOut.TabIndex = 20;
            // 
            // CalculateBtn
            // 
            this.CalculateBtn.Location = new System.Drawing.Point(122, 274);
            this.CalculateBtn.Name = "CalculateBtn";
            this.CalculateBtn.Size = new System.Drawing.Size(105, 32);
            this.CalculateBtn.TabIndex = 21;
            this.CalculateBtn.Text = "Calculate";
            this.CalculateBtn.UseVisualStyleBackColor = true;
            this.CalculateBtn.Click += new System.EventHandler(this.CalculateBtn_Click);
            // 
            // ClearBtn
            // 
            this.ClearBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.ClearBtn.Location = new System.Drawing.Point(325, 274);
            this.ClearBtn.Name = "ClearBtn";
            this.ClearBtn.Size = new System.Drawing.Size(94, 32);
            this.ClearBtn.TabIndex = 22;
            this.ClearBtn.Text = "Clear";
            this.ClearBtn.UseVisualStyleBackColor = true;
            this.ClearBtn.Click += new System.EventHandler(this.ClearBtn_Click);
            // 
            // Program1
            // 
            this.AcceptButton = this.CalculateBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.ClearBtn;
            this.ClientSize = new System.Drawing.Size(584, 362);
            this.Controls.Add(this.ClearBtn);
            this.Controls.Add(this.CalculateBtn);
            this.Controls.Add(this.totalcOut);
            this.Controls.Add(this.LabrCOut);
            this.Controls.Add(this.PdingCOut);
            this.Controls.Add(this.CrptcOut);
            this.Controls.Add(this.SqYrdOut);
            this.Controls.Add(this.totalcIn);
            this.Controls.Add(this.LabrCIn);
            this.Controls.Add(this.PdingCIn);
            this.Controls.Add(this.CrptcIn);
            this.Controls.Add(this.SqYrdIn);
            this.Controls.Add(this.isRoomInput);
            this.Controls.Add(this.PadInput);
            this.Controls.Add(this.isRoomLbl);
            this.Controls.Add(this.paddingInput);
            this.Controls.Add(this.crptPriceInput);
            this.Controls.Add(this.CrptPrLbl);
            this.Controls.Add(this.RmLengthInput);
            this.Controls.Add(this.RmLengthLbl);
            this.Controls.Add(this.RmWidthInput);
            this.Controls.Add(this.rmWidthLbl);
            this.Controls.Add(this.welcomeLBL);
            this.Name = "Program1";
            this.Text = "Program1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label welcomeLBL;
        private System.Windows.Forms.Label rmWidthLbl;
        private System.Windows.Forms.TextBox RmWidthInput;
        private System.Windows.Forms.Label RmLengthLbl;
        private System.Windows.Forms.TextBox RmLengthInput;
        private System.Windows.Forms.Label CrptPrLbl;
        private System.Windows.Forms.TextBox crptPriceInput;
        private System.Windows.Forms.Label paddingInput;
        private System.Windows.Forms.Label isRoomLbl;
        private System.Windows.Forms.TextBox PadInput;
        private System.Windows.Forms.TextBox isRoomInput;
        private System.Windows.Forms.Label SqYrdIn;
        private System.Windows.Forms.Label CrptcIn;
        private System.Windows.Forms.Label PdingCIn;
        private System.Windows.Forms.Label LabrCIn;
        private System.Windows.Forms.Label totalcIn;
        private System.Windows.Forms.Label SqYrdOut;
        private System.Windows.Forms.Label CrptcOut;
        private System.Windows.Forms.Label PdingCOut;
        private System.Windows.Forms.Label LabrCOut;
        private System.Windows.Forms.Label totalcOut;
        private System.Windows.Forms.Button CalculateBtn;
        private System.Windows.Forms.Button ClearBtn;
    }
}

