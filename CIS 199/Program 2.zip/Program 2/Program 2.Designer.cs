﻿namespace Program_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.taxableincLbl = new System.Windows.Forms.Label();
            this.taxinput = new System.Windows.Forms.TextBox();
            this.RadioLbl = new System.Windows.Forms.Label();
            this.singleRadioBtn = new System.Windows.Forms.RadioButton();
            this.MarriedRadioBtn = new System.Windows.Forms.RadioButton();
            this.SeperatleyRadioBtn = new System.Windows.Forms.RadioButton();
            this.HeadRadioBtn = new System.Windows.Forms.RadioButton();
            this.CalcInputsBtn = new System.Windows.Forms.Button();
            this.amountDueOutput = new System.Windows.Forms.Label();
            this.AmountDueLbl = new System.Windows.Forms.Label();
            this.MarginalRateLbl = new System.Windows.Forms.Label();
            this.MarginalrateOutput = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // taxableincLbl
            // 
            this.taxableincLbl.AutoSize = true;
            this.taxableincLbl.Location = new System.Drawing.Point(24, 43);
            this.taxableincLbl.Name = "taxableincLbl";
            this.taxableincLbl.Size = new System.Drawing.Size(112, 13);
            this.taxableincLbl.TabIndex = 0;
            this.taxableincLbl.Text = "Enter taxable income: ";
            // 
            // taxinput
            // 
            this.taxinput.Location = new System.Drawing.Point(142, 40);
            this.taxinput.Name = "taxinput";
            this.taxinput.Size = new System.Drawing.Size(100, 20);
            this.taxinput.TabIndex = 1;
            // 
            // RadioLbl
            // 
            this.RadioLbl.AutoSize = true;
            this.RadioLbl.Location = new System.Drawing.Point(56, 78);
            this.RadioLbl.Name = "RadioLbl";
            this.RadioLbl.Size = new System.Drawing.Size(103, 13);
            this.RadioLbl.TabIndex = 2;
            this.RadioLbl.Text = "Select Filing Status: ";
            // 
            // singleRadioBtn
            // 
            this.singleRadioBtn.AutoSize = true;
            this.singleRadioBtn.Checked = true;
            this.singleRadioBtn.Location = new System.Drawing.Point(55, 105);
            this.singleRadioBtn.Name = "singleRadioBtn";
            this.singleRadioBtn.Size = new System.Drawing.Size(81, 17);
            this.singleRadioBtn.TabIndex = 3;
            this.singleRadioBtn.TabStop = true;
            this.singleRadioBtn.Text = "Filing Single";
            this.singleRadioBtn.UseVisualStyleBackColor = true;
            // 
            // MarriedRadioBtn
            // 
            this.MarriedRadioBtn.AutoSize = true;
            this.MarriedRadioBtn.Location = new System.Drawing.Point(55, 128);
            this.MarriedRadioBtn.Name = "MarriedRadioBtn";
            this.MarriedRadioBtn.Size = new System.Drawing.Size(119, 17);
            this.MarriedRadioBtn.TabIndex = 4;
            this.MarriedRadioBtn.Text = "Married Filing Jointly";
            this.MarriedRadioBtn.UseVisualStyleBackColor = true;
            // 
            // SeperatleyRadioBtn
            // 
            this.SeperatleyRadioBtn.AutoSize = true;
            this.SeperatleyRadioBtn.Location = new System.Drawing.Point(55, 174);
            this.SeperatleyRadioBtn.Name = "SeperatleyRadioBtn";
            this.SeperatleyRadioBtn.Size = new System.Drawing.Size(140, 17);
            this.SeperatleyRadioBtn.TabIndex = 5;
            this.SeperatleyRadioBtn.Text = "Married Filing Seperately";
            this.SeperatleyRadioBtn.UseVisualStyleBackColor = true;
            // 
            // HeadRadioBtn
            // 
            this.HeadRadioBtn.AutoSize = true;
            this.HeadRadioBtn.Location = new System.Drawing.Point(55, 151);
            this.HeadRadioBtn.Name = "HeadRadioBtn";
            this.HeadRadioBtn.Size = new System.Drawing.Size(117, 17);
            this.HeadRadioBtn.TabIndex = 6;
            this.HeadRadioBtn.Text = "Head of Household";
            this.HeadRadioBtn.UseVisualStyleBackColor = true;
            // 
            // CalcInputsBtn
            // 
            this.CalcInputsBtn.Location = new System.Drawing.Point(74, 197);
            this.CalcInputsBtn.Name = "CalcInputsBtn";
            this.CalcInputsBtn.Size = new System.Drawing.Size(135, 27);
            this.CalcInputsBtn.TabIndex = 7;
            this.CalcInputsBtn.Text = "Calculate Taxes Owed";
            this.CalcInputsBtn.UseVisualStyleBackColor = true;
            this.CalcInputsBtn.Click += new System.EventHandler(this.CalcInputsBtn_Click);
            // 
            // amountDueOutput
            // 
            this.amountDueOutput.Location = new System.Drawing.Point(155, 233);
            this.amountDueOutput.Name = "amountDueOutput";
            this.amountDueOutput.Size = new System.Drawing.Size(119, 24);
            this.amountDueOutput.TabIndex = 8;
            this.amountDueOutput.Text = "$ 0.00";
            this.amountDueOutput.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // AmountDueLbl
            // 
            this.AmountDueLbl.Location = new System.Drawing.Point(52, 239);
            this.AmountDueLbl.Name = "AmountDueLbl";
            this.AmountDueLbl.Size = new System.Drawing.Size(97, 23);
            this.AmountDueLbl.TabIndex = 9;
            this.AmountDueLbl.Text = "Tax Amount Due:";
            // 
            // MarginalRateLbl
            // 
            this.MarginalRateLbl.Location = new System.Drawing.Point(52, 268);
            this.MarginalRateLbl.Name = "MarginalRateLbl";
            this.MarginalRateLbl.Size = new System.Drawing.Size(97, 23);
            this.MarginalRateLbl.TabIndex = 10;
            this.MarginalRateLbl.Text = "Marginal Tax Rate:";
            // 
            // MarginalrateOutput
            // 
            this.MarginalrateOutput.Location = new System.Drawing.Point(158, 268);
            this.MarginalrateOutput.Name = "MarginalrateOutput";
            this.MarginalrateOutput.Size = new System.Drawing.Size(51, 23);
            this.MarginalrateOutput.TabIndex = 11;
            this.MarginalrateOutput.Text = "0 %";
            // 
            // Form1
            // 
            this.AcceptButton = this.CalcInputsBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(308, 321);
            this.Controls.Add(this.MarginalrateOutput);
            this.Controls.Add(this.MarginalRateLbl);
            this.Controls.Add(this.AmountDueLbl);
            this.Controls.Add(this.amountDueOutput);
            this.Controls.Add(this.CalcInputsBtn);
            this.Controls.Add(this.HeadRadioBtn);
            this.Controls.Add(this.SeperatleyRadioBtn);
            this.Controls.Add(this.MarriedRadioBtn);
            this.Controls.Add(this.singleRadioBtn);
            this.Controls.Add(this.RadioLbl);
            this.Controls.Add(this.taxinput);
            this.Controls.Add(this.taxableincLbl);
            this.Name = "Form1";
            this.Text = "Program 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label taxableincLbl;
        private System.Windows.Forms.TextBox taxinput;
        private System.Windows.Forms.Label RadioLbl;
        private System.Windows.Forms.RadioButton singleRadioBtn;
        private System.Windows.Forms.RadioButton MarriedRadioBtn;
        private System.Windows.Forms.RadioButton SeperatleyRadioBtn;
        private System.Windows.Forms.RadioButton HeadRadioBtn;
        private System.Windows.Forms.Button CalcInputsBtn;
        private System.Windows.Forms.Label amountDueOutput;
        private System.Windows.Forms.Label AmountDueLbl;
        private System.Windows.Forms.Label MarginalRateLbl;
        private System.Windows.Forms.Label MarginalrateOutput;
    }
}

