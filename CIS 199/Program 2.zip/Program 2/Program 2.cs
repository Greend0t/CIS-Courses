﻿//Grade ID: N8838
//CIS 199-75
//Program 2
//Due Date: 3/5/2019
// This Application will determine an individual's Federal marginal income tax rate and income tax amount due given the individual's taxable income and filing status, for 2019.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Console;

namespace Program_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CalcInputsBtn_Click(object sender, EventArgs e) //My button name 
        {
            
            bool validIncome; // using bool to nest ifs statment example: if (validIncome) {Steps here}
            const double rate1 = 0.10; // this is 10% rate variable
            const double rate2 = 0.12; //12% marginal rate
            const double rate3 = 0.22; //22% marginal rate
            const double rate4 = 0.24; // 24% marginal rate
            const double rate5 = 0.32; // 32% marginal rate
            const double rate6 = 0.35; //35% marginal rate
            const double rate7 = 0.37; //37% marginal rate
            double MarginalRate = 0; // this will show the marginal rate in text label set at 0
            

            const double single1 = 9700; //These are constant rates for Single filing in level 1
            const double single2 = 39475; //These are constant rates for Single filing in level 2
            const double single3 = 84200; //These are constant rates for Single filing in level 3
            const double single4 = 160725; //These are constant rates for Single filing in level 4
            const double single5 = 204100; //These are constant rates for Single filing in level 5
            const double single6 = 510300; //These are constant rates for Single filing in level 6 

            const double marriedjoint1 = 19400; //Constants for married filing joint level 1
            const double marriedjoint2 = 78950; //Constants for married filing joint level 2
            const double marriedjoint3 = 168400; //Constants for married filing joint level 3
            const double marriedjoint4 = 321450; //Constants for married filing joint level 4
            const double marriedjoint5 = 408200; //Constants for married filing joint level 5
            const double marriedjoint6 = 612350; //Constants for married filing joint level 6

            const double headofhouse1 = 13850; //Constants for head of house hold level 1
            const double headofhouse2 = 52850;  //Constants for head of house hold level 2
            const double headofhouse3 = 84200; //Constants for head of house hold level 3
            const double headofhouse4 = 160700; //Constants for head of house hold level 4
            const double headofhouse5 = 204100; //Constants for head of house hold level 5
            const double headofhouse6 = 510300; //Constants for head of house hold level 6

            const double Seperately1 = 9700; //Constatns for MArried Filing Seperately level 1
            const double Seperately2 = 39475; //Constatns for MArried Filing Seperately level 2
            const double Seperately3 = 84200; //Constatns for MArried Filing Seperately level 3
            const double Seperately4 = 160725; //Constatns for MArried Filing Seperately level 4
            const double Seperately5 = 204100; //Constatns for MArried Filing Seperately level 5
            const double Seperately6 = 306175; //Constatns for MArried Filing Seperately level 6

            double amountDue = 0;
            double taxableIncome = 0; // this will be the user inputs
            
           validIncome = double.TryParse(taxinput.Text, out taxableIncome); // using TryParse method to enure amount entered as numerical only and using bool Valid makes nesting easir for me.

            if (taxableIncome <= 0) //this will ensure that the user enters amount greater than 0 otherwise it will give them an error below

                MessageBox.Show("Please enter a correct dollars amount.","Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error); // this is my error message box shows an x and ok to return with sound :D

            else if (validIncome) // if entry is valid calculation will continue
            {
                if (singleRadioBtn.Checked) // if single radio button is checked it will do below nesting
                {
                    
                    if (taxableIncome <= single1) // if lower than single1 variable it will use the formula belwo
                    {
                        amountDue = taxableIncome * rate1; //this will give 10% rate since its lower than bracket 1
                        MarginalRate = rate1;
                        
                    }

                    else if ((taxableIncome <= single2) ) // this will calculate the second bracket for single if it is greater than single 1 and lower than single 2
                    {
                        amountDue = (single1 * rate1) + (single2 - single1) * rate2 + (taxableIncome - single2) * rate2; //this will give 12% rate since its lower than bracket 2 but not lower than 1
                        MarginalRate = rate2;
                        
                    }

                    else if ((taxableIncome <= single3)) // this will calculate the third bracket for single if it is greater than single 2 and lower than single 3
                    {
                        amountDue =     //rate 3 variable formula
                        (single1 * rate1) +
                        (single2 - single1) * rate2 +
                        (single3 - single2) * rate3 +
                        (taxableIncome - single3) * rate3;

                        MarginalRate = rate3; 
                    }

                    else if ((taxableIncome <= single4)) // this will calculate if lower than single4 and greater than single3 
                    {
                        amountDue = //this will calculate the income that will be owed and will show rate4
                        (single1 * rate1) +
                        (single2 - single1) * rate2 +
                        (single3 - single2) * rate3 +
                        (single4 - single3) * rate4 +
                        (taxableIncome - single4) * rate4;
                        MarginalRate = rate4;
                    }
                     
                    else if ((taxableIncome <= single5) ) // this will calculate if lower than single5 and greater than single4 
                    {
                        amountDue = //this will calculate the income that will be owed and will show rate5
                        (single1 * rate1) +
                        (single2 - single1) * rate2 +
                        (single3 - single2) * rate3 +
                        (single4 - single3) * rate4 +
                        (single5 - single4) * rate5 +
                        (taxableIncome - single5) * rate5;
                        MarginalRate = rate5;
                    }

                   else if ((taxableIncome <= single6) ) // this will calculate if lower than single6 and greater than single5 
                    {
                        amountDue = (single1 * rate1) + //this will calculate the income that will be owed and will show rate6
                           (single2 - single1) * rate2 +
                           (single3 - single2) * rate3 +
                           (single4 - single3) * rate4 +
                           (single5 - single4) * rate5 +
                           (single6 - single5) * rate6 +
                           (taxableIncome - single6) * rate6;
                        MarginalRate = rate6;
                        
                    }

                   else // last beacket calculation if greater than single 6 this will be shown taxed at rate7
                    {
                        amountDue = (single1 * rate1) +
                        (single2 - single1) * rate2 +
                        (single3 - single2) * rate3 +
                        (single4 - single3) * rate4 +
                        (single5 - single4) * rate5 +
                        (single6 - single5) * rate6 +
                        (taxableIncome - single6) * rate7;
                        MarginalRate = rate7;
                        
                    }

                }

                else if (MarriedRadioBtn.Checked) // these are indication if radio buttons are checked then it will use my variables to calculate see comments above
                {
                    if (taxableIncome <= marriedjoint1)
                    {
                        amountDue = taxableIncome * rate1;
                        MarginalRate = rate1;
                        
                    }
                    else if ((taxableIncome <= marriedjoint2))
                    
                    {
                        amountDue = (marriedjoint1 * rate1) + (marriedjoint2 - marriedjoint1) * rate2 + (taxableIncome - marriedjoint2) * rate2;
                        MarginalRate = rate2;
                       
                    }
                    else if ((taxableIncome <= marriedjoint3))
                    
                    {
                        amountDue =
                        (marriedjoint1 * rate1) +
                        (marriedjoint2 - marriedjoint1) * rate2 +
                        (marriedjoint3 - marriedjoint2) * rate3 +
                        (taxableIncome - marriedjoint3) * rate3;

                        MarginalRate = rate3;
                    }

                   else if ((taxableIncome <= marriedjoint4))
                    
                    {
                        amountDue =
                        (marriedjoint1 * rate1) +
                        (marriedjoint2 - marriedjoint1) * rate2 +
                        (marriedjoint3 - marriedjoint2) * rate3 +
                        (marriedjoint4 - marriedjoint3) * rate4 +
                        (taxableIncome - marriedjoint4) * rate4;
                        MarginalRate = rate4;
                    }

                    else if ((taxableIncome <= marriedjoint5))
                    
                    {
                        amountDue =
                        (marriedjoint1 * rate1) +
                        (marriedjoint2 - marriedjoint1) * rate2 +
                        (marriedjoint3 - marriedjoint2) * rate3 +
                        (marriedjoint4 - marriedjoint3) * rate4 +
                        (marriedjoint5 - marriedjoint4) * rate5 +
                        (taxableIncome - marriedjoint5) * rate5;
                        MarginalRate = rate5;
                    }

                    else if ((taxableIncome <= marriedjoint6))
                    
                    {
                        amountDue =
                        (marriedjoint1 * rate1) +
                        (marriedjoint2 - marriedjoint1) * rate2 +
                        (marriedjoint3 - marriedjoint2) * rate3 +
                        (marriedjoint4 - marriedjoint3) * rate4 +
                        (marriedjoint5 - marriedjoint4) * rate5 +
                        (taxableIncome - marriedjoint5) * rate6;
                        MarginalRate = rate6;
                    }

                    else
                    {
                        amountDue = (marriedjoint1 * rate1) +
                        (marriedjoint2 - marriedjoint1) * rate2 +
                        (marriedjoint3 - marriedjoint2) * rate3 +
                        (marriedjoint4 - marriedjoint3) * rate4 +
                        (marriedjoint5 - marriedjoint4) * rate5 +
                        (marriedjoint6 - marriedjoint5) * rate6 +
                        (taxableIncome - marriedjoint6) * rate7;
                        MarginalRate = rate7;
                        
                    }
                }

                else if (HeadRadioBtn.Checked)
                {
                    if (taxableIncome <= headofhouse1)
                    
                        {
                        amountDue = taxableIncome * rate1;
                            MarginalRate = rate1;
                            
                        }

                   else if ((taxableIncome <=headofhouse2))
                        {
                        amountDue = (headofhouse1 * rate1) + (headofhouse2 - headofhouse1) * rate2 + (taxableIncome - headofhouse2) * rate2;
                            MarginalRate = rate2;
                            
                        }
                    else if ((taxableIncome <= headofhouse3))
                        {
                        amountDue =
                    (headofhouse1 * rate1) +
                        (headofhouse2 - headofhouse1) * rate2 +
                        (headofhouse3 - headofhouse2) * rate3 +
                        (taxableIncome - headofhouse3) * rate3;

                            MarginalRate = rate3; 
                        }
                    else if ((taxableIncome <= headofhouse4))
                        {
                        amountDue =
                    (headofhouse1 * rate1) +
                        (headofhouse2 - headofhouse1) * rate2 +
                        (headofhouse3 - headofhouse2) * rate3 +
                        (headofhouse4 - headofhouse3) * rate4 +
                        (taxableIncome - headofhouse4) * rate4;
                            MarginalRate = rate4;
                        }
                   else if ((taxableIncome <= headofhouse5))
                        {
                        amountDue =
                    (headofhouse1 * rate1) +
                        (headofhouse2 - headofhouse1) * rate2 +
                        (headofhouse3 - headofhouse2) * rate3 +
                        (headofhouse4 - headofhouse3) * rate4 +
                        (headofhouse5 - headofhouse4) * rate5 +
                        (taxableIncome - headofhouse5) * rate5;
                            MarginalRate = rate5;
                        }
                   else if ((taxableIncome <= headofhouse6))
                        {
                        amountDue =
                    (headofhouse1 * rate1) +
                        (headofhouse2 - headofhouse1) * rate2 +
                        (headofhouse3 - headofhouse2) * rate3 +
                        (headofhouse4 - headofhouse3) * rate4 +
                        (headofhouse5 - headofhouse4) * rate5 +
                        (headofhouse6 - headofhouse5) * rate6 +
                        (taxableIncome - headofhouse6) * rate6;
                            MarginalRate = rate6;
                        }
                    else
                        {
                        amountDue =
                    (headofhouse1 * rate1) +
                        (headofhouse2 - headofhouse1) * rate2 +
                        (headofhouse3 - headofhouse2) * rate3 +
                        (headofhouse4 - headofhouse3) * rate4 +
                        (headofhouse5 - headofhouse4) * rate5 +
                        (headofhouse6 - headofhouse5) * rate6 +
                        (taxableIncome - headofhouse6) * rate7;
                            MarginalRate = rate7;
                        }
                    }
                else if (SeperatleyRadioBtn.Checked)
                {
                    if (taxableIncome <= Seperately1)
                    {
                        amountDue = taxableIncome * rate1;
                        MarginalRate = rate1;
                        
                        MarginalRate = rate1;
                    }

                    else if ((taxableIncome <= Seperately2))
                    {
                        amountDue = (Seperately1 * rate1) + (Seperately2 - Seperately1) * rate2 + (taxableIncome - Seperately2) * rate2;
                        MarginalRate = rate2;
                    }

                   else if ((taxableIncome <= Seperately3))
                    {
                        amountDue =
                        (Seperately1 * rate1) +
                        (Seperately2 - Seperately1) * rate2 +
                        (Seperately3 - Seperately2) * rate3 +
                        (taxableIncome - Seperately3) * rate3;
                        MarginalRate = rate3; 
                    }

                   else if ((taxableIncome <= Seperately4))
                    {
                        amountDue =
                        (Seperately1 * rate1) +
                        (Seperately2 - Seperately1) * rate2 +
                        (Seperately3 - Seperately2) * rate3 +
                        (Seperately4 - Seperately3) * rate4 +
                        (taxableIncome - Seperately4) * rate4;
                        MarginalRate = rate4;
                    }

                    else if ((taxableIncome <= Seperately5))
                    {
                        amountDue =
                       (Seperately1 * rate1) +
                       (Seperately2 - Seperately1) * rate2 +
                       (Seperately3 - Seperately2) * rate3 +
                       (Seperately4 - Seperately3) * rate4 +
                       (Seperately5 - Seperately4) * rate5 +
                       (taxableIncome - Seperately5) * rate5;
                        MarginalRate = rate5;
                    }

                   else if ((taxableIncome <= Seperately6))
                    {
                        amountDue = (Seperately1 * rate1) +
                       (Seperately2 - Seperately1) * rate2 +
                       (Seperately3 - Seperately2) * rate3 +
                       (Seperately4 - Seperately3) * rate4 +
                       (Seperately5 - Seperately4) * rate5 +
                       (Seperately6 - Seperately5) * rate6 +
                       (taxableIncome - Seperately6) * rate6;
                        MarginalRate = rate6;
                    }

                    else
                    {
                        amountDue = (Seperately1 * rate1) + (Seperately2 - Seperately1) * rate2 + (Seperately3 - Seperately2) * rate3 + (Seperately4 - Seperately3) * rate4 + (Seperately5 - Seperately4) * rate5 + (Seperately6 - Seperately5) * rate6 + (taxableIncome - Seperately6) * rate7;
                        MarginalRate = rate7;
                        
                    }

                }

                }
            
            else
            {
                MessageBox.Show("Please enter a correct dollars amount.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error); //Error with an X logo and ok button :D
            }

                amountDueOutput.Text = $"{amountDue:C}"; // this will show dollar amount due, in C as currency
                MarginalrateOutput.Text = $"{MarginalRate:P0}"; // My output texts results will be shown in form this P as percentage 
            }
        }
    }

    
