﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Console;

namespace Program_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CalcInputsBtn_Click(object sender, EventArgs e) //My button name 
        {
            double taxableIncome = 0;
            bool validIncome;
            const double rate1 = 0.10; // this is 10% rate variable
            const double rate2 = 0.12; //12% marginal rate
            const double rate3 = 0.22; //22% marginal rate
            const double rate4 = 0.24; // 24% marginal rate
            const double rate5 = 0.32; // 32% marginal rate
            const double rate6 = 0.35; //35% marginal rate
            const double rate7 = 0.37; //37% marginal rate
            double MarginalRate = 0; // this will show the marginal rate in text label set at 0

            const double single1 = 9700;
            const double single2 = 39475;
            const double single3 = 84200;
            const double single4 = 160725;
            const double single5 = 204100;
            const double single6 = 510300;

            const double marriedjoint1 = 19400;
            const double marriedjoint2 = 78950;
            const double marriedjoint3 = 168400;
            const double marriedjoint4 = 321450;
            const double marriedjoint5 = 408200;
            const double marriedjoint6 = 612350;

            const double headofhouse1 = 13850;
            const double headofhouse2 = 52850;
            const double headofhouse3 = 84200;
            const double headofhouse4 = 160700;
            const double headofhouse5 = 204100;
            const double headofhouse6 = 510300;

            const double Seperately1 = 9700;
            const double Seperately2 = 39475;
            const double Seperately3 = 84200;
            const double Seperately4 = 160700;
            const double Seperately5 = 204100;
            const double Seperately6 = 510300;


            validIncome = double.TryParse(taxinput.Text, out taxableIncome);

            if (validIncome)
            {
                if (singleRadioBtn.Checked)
                {
                    
                    if (taxableIncome <= single1)
                    {
                        taxableIncome = taxableIncome * rate1;
                        MarginalRate = rate1;
                        //good dont touch rate 1}
                    }

                    if ((taxableIncome <= single2) && (taxableIncome > single1))
                    {
                        taxableIncome = (single1 * rate1) + (single2 - single1) * rate2 + (taxableIncome - single2) * rate2;
                        MarginalRate = rate2;
                        //this is good calc rate 2
                    }

                    if ((taxableIncome <= single3) && (taxableIncome > single2))
                    {
                        taxableIncome =
                        (single1 * rate1) +
                        (single2 - single1) * rate2 +
                        (single3 - single2) * rate3 +
                        (taxableIncome - single3) * rate3;

                        MarginalRate = rate3; //this is good don't touch rate 3
                    }

                    if ((taxableIncome <= single4) && (taxableIncome >single3))
                    {
                        taxableIncome =
                        (single1 * rate1) +
                        (single2 - single1) * rate2 +
                        (single3 - single2) * rate3 +
                        (single4 - single3) * rate4 +
                        (taxableIncome - single4) * rate4;
                        MarginalRate = rate4;
                    }

                    if ((taxableIncome <= single5) && (taxableIncome > single4))
                    {
                        taxableIncome =
                        (single1 * rate1) +
                        (single2 - single1) * rate2 +
                        (single3 - single2) * rate3 +
                        (single4 - single3) * rate4 +
                        (single5 - single4) * rate5 +
                        (taxableIncome - single5) * rate5;
                        MarginalRate = rate5;
                    }

                    if ((taxableIncome <= single6) && (taxableIncome > single4))
                    {
                        taxableIncome = (single1 * rate1) +
                           (single2 - single1) * rate2 +
                           (single3 - single2) * rate3 +
                           (single4 - single3) * rate4 +
                           (single5 - single4) * rate5 +
                           (single6 - single5) * rate6 +
                           (taxableIncome - single6) * rate6;
                        MarginalRate = rate6;
                        //calculate rate 6 250k and 500k 
                    }

                    if ((taxableIncome > single6) && (taxableIncome > single5))
                    {
                        taxableIncome = (single1 * rate1) +
                        (single2 - single1) * rate2 +
                        (single3 - single2) * rate3 +
                        (single4 - single3) * rate4 +
                        (single5 - single4) * rate5 +
                        (single6 - single5) * rate6 +
                        (taxableIncome - single6) * rate7;
                        MarginalRate = rate7;
                        //calculates over 1million
                    }

                }//single checked

                else if (MarriedRadioBtn.Checked)
                {
                    if (taxableIncome <= marriedjoint1)
                    {
                        taxableIncome = taxableIncome * rate1;
                        MarginalRate = rate1;
                        //good dont touch rate 1
                    }
                    if ((taxableIncome <= marriedjoint2) && (taxableIncome > marriedjoint1))
                    //if ((taxableIncome <= marriedjoint2) && (taxableIncome > marriedjoint1))
                    {
                        taxableIncome = (marriedjoint1 * rate1) + (marriedjoint2 - marriedjoint1) * rate2 + (taxableIncome - marriedjoint2) * rate2;
                        MarginalRate = rate2;
                        //this is good calc rate 2
                    }
                    if ((taxableIncome <= marriedjoint3) && (taxableIncome > marriedjoint2))
                    //if ((taxableIncome > marriedjoint3) && (taxableIncome <= marriedjoint3))
                    {
                        taxableIncome =
                        (marriedjoint1 * rate1) +
                        (marriedjoint2 - marriedjoint1) * rate2 +
                        (marriedjoint3 - marriedjoint2) * rate3 +
                        (taxableIncome - marriedjoint3) * rate3;

                        MarginalRate = rate3; //this is good don't touch rate 3
                    }

                    if ((taxableIncome <= marriedjoint4) && (taxableIncome > marriedjoint3))
                    //if (taxableIncome <= marriedjoint4)
                    {
                        taxableIncome =
                        (marriedjoint1 * rate1) +
                        (marriedjoint2 - marriedjoint1) * rate2 +
                        (marriedjoint3 - marriedjoint2) * rate3 +
                        (marriedjoint4 - marriedjoint3) * rate4 +
                        (taxableIncome - marriedjoint4) * rate4;
                        MarginalRate = rate4;
                    }

                    if ((taxableIncome <= marriedjoint5) && (taxableIncome > marriedjoint4))
                    //if (taxableIncome >= marriedjoint5)
                    {
                        taxableIncome =
                        (marriedjoint1 * rate1) +
                        (marriedjoint2 - marriedjoint1) * rate2 +
                        (marriedjoint3 - marriedjoint2) * rate3 +
                        (marriedjoint4 - marriedjoint3) * rate4 +
                        (marriedjoint5 - marriedjoint4) * rate5 +
                        (taxableIncome - marriedjoint5) * rate5;
                        MarginalRate = rate4;
                    }

                    if ((taxableIncome <= marriedjoint6) && (taxableIncome > marriedjoint5))
                    //if (taxableIncome <= marriedjoint6)
                    {
                        taxableIncome =
                        (marriedjoint1 * rate1) +
                        (marriedjoint2 - marriedjoint1) * rate2 +
                        (marriedjoint3 - marriedjoint2) * rate3 +
                        (marriedjoint4 - marriedjoint3) * rate4 +
                        (marriedjoint5 - marriedjoint4) * rate5 +
                        (taxableIncome - marriedjoint5) * rate6;
                        MarginalRate = rate4;
                    }

                    if ((taxableIncome > marriedjoint6) && (taxableIncome > marriedjoint5))
                    {
                        taxableIncome = (marriedjoint1 * rate1) +
                        (marriedjoint2 - marriedjoint1) * rate2 +
                        (marriedjoint3 - marriedjoint2) * rate3 +
                        (marriedjoint4 - marriedjoint3) * rate4 +
                        (marriedjoint5 - marriedjoint4) * rate5 +
                        (marriedjoint6 - marriedjoint5) * rate6 +
                        (taxableIncome - marriedjoint6) * rate7;
                        MarginalRate = rate7;
                        //calculates over 1million
                    }
                }

                else if (HeadRadioBtn.Checked)
                {
                    if (taxableIncome <= headofhouse1)
                    
                        {
                            taxableIncome = taxableIncome * rate1;
                            MarginalRate = rate1;
                            //good dont touch rate 1
                        }

                    if ((taxableIncome <=headofhouse2) && (taxableIncome > headofhouse1))
                        {
                            taxableIncome = (headofhouse1 * rate1) + (headofhouse2 - headofhouse1) * rate2 + (taxableIncome - headofhouse2) * rate2;
                            MarginalRate = rate2;
                            //this is good calc rate 2
                        }
                    if ((taxableIncome <= headofhouse3) && (taxableIncome > headofhouse2))
                        {
                            taxableIncome =
                        (headofhouse1 * rate1) +
                        (headofhouse2 - headofhouse1) * rate2 +
                        (headofhouse3 - headofhouse2) * rate3 +
                        (taxableIncome - headofhouse3) * rate3;

                            MarginalRate = rate3; //this is good don't touch rate 3
                        }
                    if ((taxableIncome <= headofhouse4) && (taxableIncome > headofhouse3))
                        {
                            taxableIncome =
                        (headofhouse1 * rate1) +
                        (headofhouse2 - headofhouse1) * rate2 +
                        (headofhouse3 - headofhouse2) * rate3 +
                        (headofhouse4 - headofhouse3) * rate4 +
                        (taxableIncome - headofhouse4) * rate4;
                            MarginalRate = rate4;
                        }
                    if ((taxableIncome <= headofhouse5) && (taxableIncome > headofhouse4))
                        {
                            taxableIncome =
                        (headofhouse1 * rate1) +
                        (headofhouse2 - headofhouse1) * rate2 +
                        (headofhouse3 - headofhouse2) * rate3 +
                        (headofhouse4 - headofhouse3) * rate4 +
                        (headofhouse5 - headofhouse4) * rate5 +
                        (taxableIncome - headofhouse5) * rate5;
                            MarginalRate = rate5;
                        }
                    if ((taxableIncome <= headofhouse6) && (taxableIncome > headofhouse4))
                        {
                            taxableIncome =
                        (headofhouse1 * rate1) +
                        (headofhouse2 - headofhouse1) * rate2 +
                        (headofhouse3 - headofhouse2) * rate3 +
                        (headofhouse4 - headofhouse3) * rate4 +
                        (headofhouse5 - headofhouse4) * rate5 +
                        (headofhouse6 - headofhouse5) * rate6 +
                        (taxableIncome - headofhouse6) * rate6;
                            MarginalRate = rate6;
                        }
                    if ((taxableIncome > headofhouse6) && (taxableIncome > headofhouse5))
                        {
                            taxableIncome =
                        (headofhouse1 * rate1) +
                        (headofhouse2 - headofhouse1) * rate2 +
                        (headofhouse3 - headofhouse2) * rate3 +
                        (headofhouse4 - headofhouse3) * rate4 +
                        (headofhouse5 - headofhouse4) * rate5 +
                        (headofhouse6 - headofhouse5) * rate6 +
                        (taxableIncome - headofhouse6) * rate7;
                            MarginalRate = rate7;
                        }
                    }
                else if (SeperatleyRadioBtn.Checked)
                {
                    if (taxableIncome <= Seperately1)
                    {
                        taxableIncome = taxableIncome * rate1;
                        MarginalRate = rate1;
                        //good dont touch rate 1}
                        MarginalRate = rate1;
                    }

                    if ((taxableIncome <= Seperately2) && (taxableIncome > Seperately1))
                    {
                        taxableIncome = (Seperately1 * rate1) + (Seperately2 - Seperately1) * rate2 + (taxableIncome - Seperately2) * rate2;
                        MarginalRate = rate2;
                    }

                    if ((taxableIncome <= Seperately3) && (taxableIncome > Seperately2))
                    {
                        taxableIncome =
                        (Seperately1 * rate1) +
                        (Seperately2 - Seperately1) * rate2 +
                        (Seperately3 - Seperately2) * rate3 +
                        (taxableIncome - Seperately3) * rate3;
                        MarginalRate = rate3; //this is good don't touch rate 3
                    }

                    if ((taxableIncome <= Seperately4) && (taxableIncome > Seperately3))
                    {
                        taxableIncome =
                        (Seperately1 * rate1) +
                        (Seperately2 - Seperately1) * rate2 +
                        (Seperately3 - Seperately2) * rate3 +
                        (Seperately4 - Seperately3) * rate4 +
                        (taxableIncome - Seperately4) * rate4;
                        MarginalRate = rate4;
                    }

                    if ((taxableIncome <= Seperately5) && (taxableIncome > Seperately4))
                    {
                        taxableIncome =
                       (Seperately1 * rate1) +
                       (Seperately2 - Seperately1) * rate2 +
                       (Seperately3 - Seperately2) * rate3 +
                       (Seperately4 - Seperately3) * rate4 +
                       (Seperately5 - Seperately4) * rate5 +
                       (taxableIncome - Seperately5) * rate5;
                        MarginalRate = rate5;
                    }

                    if ((taxableIncome <= Seperately6) && (taxableIncome > Seperately4))
                    {
                       taxableIncome = (Seperately1 * rate1) +
                       (Seperately2 - Seperately1) * rate2 +
                       (Seperately3 - Seperately2) * rate3 +
                       (Seperately4 - Seperately3) * rate4 +
                       (Seperately5 - Seperately4) * rate4 +
                       (Seperately6 - Seperately5) * rate5 +
                       (taxableIncome - Seperately6) * rate6;
                        MarginalRate = rate6;
                    }

                    if ((taxableIncome > Seperately6) && (taxableIncome > Seperately5))
                    {
                        taxableIncome = (Seperately1 * rate1) +
                         (Seperately2 - Seperately1) * rate2 +
                         (Seperately3 - Seperately2) * rate3 +
                         (Seperately4 - Seperately3) * rate4 +
                         (Seperately5 - Seperately4) * rate5 +
                         (Seperately6 - Seperately5) * rate6 +
                         (taxableIncome - Seperately6) * rate7;
                         MarginalRate = rate7;
                    }

                }

                }
            else
            {
                MessageBox.Show("Please enter a whole dollars amount.");
            }


                amountDueOutput.Text = $"{taxableIncome:C}";
                MarginalrateOutput.Text = $"{MarginalRate:P0}";
            }// valid income
        }
    }

    
